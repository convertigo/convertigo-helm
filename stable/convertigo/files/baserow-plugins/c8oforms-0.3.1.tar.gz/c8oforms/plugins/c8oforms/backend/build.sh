#!/bin/bash
# Bash strict mode: http://redsymbol.net/articles/unofficial-bash-strict-mode/
set -euo pipefail

# This file is automatically run by Baserow when the plugin is built into a Dockerfile.
# It will also be called when building the plugin in an existing container. You should
# only perform build steps in this script.

# Any install steps that will modify things in Baserow's data volume should instead
# be done in the runtime_setup.sh script next to this one. For example running some
# SQL against the embedded postgres database should not be done in this script as it
# makes no sense to do that in a Dockerfile build.

# Baserow will automatically install this python module for you so you should not
# repeat any python dependency installation steps here.

# Instead this file is ideal for any other installation custom steps here required by
# your plugin. For example installing a postgres extension used by your plugin.

# Baserow 2.x images run the backend in a uv venv that has no pip: install_plugin.sh
# then installs the plugin with the system pip3, into /baserow/.local, which the venv
# does not read, and the backend stops on "No module named 'c8oforms'". Point
# the venv at the sources of the plugin. Nothing to do on 1.x, where pip3 is the one
# of the venv.
VENV_PYTHON=/baserow/venv/bin/python
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/src"
if [[ -x "$VENV_PYTHON" ]] && ! "$VENV_PYTHON" -c "import c8oforms" 2>/dev/null; then
  SITE_PACKAGES=$("$VENV_PYTHON" -c "import sysconfig; print(sysconfig.get_paths()['purelib'])")
  echo "$SRC_DIR" > "$SITE_PACKAGES/c8oforms.pth"
  echo "c8oforms: added $SITE_PACKAGES/c8oforms.pth -> $SRC_DIR"
fi

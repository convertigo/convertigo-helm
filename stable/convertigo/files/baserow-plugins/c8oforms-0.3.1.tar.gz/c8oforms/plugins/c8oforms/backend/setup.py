#!/usr/bin/env python
import os

from setuptools import find_packages, setup

PROJECT_DIR = os.path.dirname(__file__)
REQUIREMENTS_DIR = os.path.join(PROJECT_DIR, "requirements")
VERSION = "0.3.1"


def get_requirements(env):
    with open(os.path.join(REQUIREMENTS_DIR, f"{env}.txt")) as fp:
        return [
            x.strip()
            for x in fp.read().split("\n")
            if x.strip()
            and not x.strip().startswith("#")
            and not x.strip().startswith("-")
        ]


install_requires = get_requirements("base")

setup(
    name="c8oforms",
    version=VERSION,
    url="https://www.convertigo.com",
    author="Convertigo",
    license="MIT",
    description="Baserow plugin: server side helpers for C8oForms.",
    long_description="Adds the /api/c8o/ endpoints used by C8oForms to Baserow.",
    platforms=["linux"],
    package_dir={"": "src"},
    packages=find_packages("src"),
    include_package_data=True,
    install_requires=install_requires,
)

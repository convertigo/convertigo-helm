from django.urls import re_path

from .views import AggregateTableView

app_name = "aggregate"

urlpatterns = [
    re_path(
        r"table/(?P<table_id>[0-9]+)/$",
        AggregateTableView.as_view(),
        name="table",
    ),
]

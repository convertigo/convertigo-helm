from django.conf import settings

from rest_framework import serializers
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.views import APIView

from baserow.api.decorators import map_exceptions, validate_query_parameters
from baserow.api.errors import ERROR_USER_NOT_IN_GROUP
from baserow.api.search.serializers import SearchQueryParamSerializer
from baserow.contrib.database.api.fields.serializers import FieldSerializer
from baserow.contrib.database.api.fields.errors import (
    ERROR_FIELD_DOES_NOT_EXIST,
    ERROR_FILTER_FIELD_NOT_FOUND,
    ERROR_INCOMPATIBLE_FIELD_TYPE,
)
from baserow.contrib.database.api.rows.serializers import UserFieldNamesSerializer
from baserow.contrib.database.api.tables.errors import ERROR_TABLE_DOES_NOT_EXIST
from baserow.contrib.database.api.tokens.authentications import TokenAuthentication
from baserow.contrib.database.api.tokens.errors import ERROR_NO_PERMISSION_TO_TABLE
from baserow.contrib.database.api.utils import extract_user_field_names_from_params
from baserow.contrib.database.api.views.errors import (
    ERROR_VIEW_FILTER_TYPE_DOES_NOT_EXIST,
    ERROR_VIEW_FILTER_TYPE_UNSUPPORTED_FIELD,
)
from baserow.contrib.database.fields.exceptions import (
    FieldDoesNotExist,
    FilterFieldNotFound,
    IncompatibleField,
)
from baserow.contrib.database.fields.handler import FieldHandler
from baserow.contrib.database.fields.operations import ListFieldsOperationType
from baserow.contrib.database.fields.registries import field_type_registry
from baserow.contrib.database.table.exceptions import TableDoesNotExist
from baserow.contrib.database.table.handler import TableHandler
from baserow.contrib.database.table.operations import (
    ListRowsDatabaseTableOperationType,
)
from baserow.contrib.database.tokens.exceptions import NoPermissionToTable
from baserow.contrib.database.tokens.handler import TokenHandler
from baserow.contrib.database.views.exceptions import (
    ViewFilterTypeDoesNotExist,
    ViewFilterTypeNotAllowedForField,
)
from baserow.contrib.database.views.filters import AdHocFilters
from baserow.core.db import specific_iterator
from baserow.core.exceptions import UserNotInWorkspace
from baserow.core.handler import CoreHandler

from ..exceptions import C8oAggregateError, InvalidParameter
from ..handler import TableFields, aggregate


def get_default_limit() -> int:
    return getattr(settings, "C8O_AGGREGATE_DEFAULT_LIMIT", 200)


def get_max_limit() -> int:
    return getattr(settings, "C8O_AGGREGATE_MAX_LIMIT", 5000)


class AggregateQueryParamsSerializer(
    SearchQueryParamSerializer, UserFieldNamesSerializer
):
    group_by = serializers.CharField(required=False, allow_blank=True, default="")
    aggregations = serializers.CharField(required=False, allow_blank=True, default="")
    order_by = serializers.CharField(required=False, allow_blank=True, default="")
    filter_type = serializers.CharField(required=False, default="")
    offset = serializers.IntegerField(required=False, min_value=0, default=0)
    limit = serializers.IntegerField(required=False, min_value=1)
    with_fields = serializers.BooleanField(required=False, default=False)
    # `ignore`: the group_by references that match no field of the table are
    # dropped (constant for every row) instead of refused with
    # ERROR_C8O_AGGREGATE_FIELD_NOT_FOUND.
    unknown_group_by = serializers.ChoiceField(
        choices=["error", "ignore"], required=False, default="error"
    )


def list_table_fields(request, table):
    """
    The fields of the table, as GET /api/database/fields/table/{table_id}/ answers
    them and with its checks: a client grouping a table usually needs its structure
    too, and gets both in one call.
    """

    CoreHandler().check_permissions(
        request.user,
        ListFieldsOperationType.type,
        workspace=table.database.workspace,
        context=table,
    )
    TokenHandler().check_table_permissions(
        request, ["read", "create", "update"], table, False
    )
    fields = specific_iterator(
        FieldHandler().get_base_fields_queryset().filter(table=table),
        per_content_type_queryset_hook=(
            lambda field, queryset: field_type_registry.get_by_model(
                field
            ).enhance_field_queryset(queryset, field)
        ),
    )
    return [
        field_type_registry.get_serializer(field, FieldSerializer).data
        for field in fields
    ]


class AggregateTableView(APIView):
    """
    GET /api/c8o/aggregate/table/{table_id}/

    Group by, distinct and aggregations on the rows of a table, with the filters and
    the search of the rows endpoint, without a view to prepare.
    """

    authentication_classes = APIView.authentication_classes + [TokenAuthentication]
    permission_classes = (IsAuthenticated,)

    @map_exceptions(
        {
            UserNotInWorkspace: ERROR_USER_NOT_IN_GROUP,
            TableDoesNotExist: ERROR_TABLE_DOES_NOT_EXIST,
            NoPermissionToTable: ERROR_NO_PERMISSION_TO_TABLE,
            FilterFieldNotFound: ERROR_FILTER_FIELD_NOT_FOUND,
            FieldDoesNotExist: ERROR_FIELD_DOES_NOT_EXIST,
            ViewFilterTypeDoesNotExist: ERROR_VIEW_FILTER_TYPE_DOES_NOT_EXIST,
            ViewFilterTypeNotAllowedForField: ERROR_VIEW_FILTER_TYPE_UNSUPPORTED_FIELD,
            IncompatibleField: ERROR_INCOMPATIBLE_FIELD_TYPE,
            # Baserow runs `.format(e=exc)` on the detail: escape the braces of the
            # message, which may quote a field name of the request.
            C8oAggregateError: lambda e: (
                e.error,
                HTTP_400_BAD_REQUEST,
                str(e).replace("{", "{{").replace("}", "}}"),
            ),
        }
    )
    @validate_query_parameters(AggregateQueryParamsSerializer)
    def get(self, request, table_id, query_params):
        table = TableHandler().get_table(table_id)

        # The same checks as GET /api/database/rows/table/{table_id}/: reading
        # aggregates gives nothing a user could not compute from the rows.
        CoreHandler().check_permissions(
            request.user,
            ListRowsDatabaseTableOperationType.type,
            workspace=table.database.workspace,
            context=table,
        )
        TokenHandler().check_table_permissions(request, "read", table, False)

        limit = query_params.get("limit") or get_default_limit()
        if limit > get_max_limit():
            # Refused rather than truncated: truncated totals are what this
            # endpoint exists to avoid. The client pages with `offset`.
            raise InvalidParameter(
                f"`limit` is at most {get_max_limit()}: page with `offset` to read "
                "more groups."
            )

        user_field_names = extract_user_field_names_from_params(request.GET)
        model = table.get_model()
        queryset = model.objects.all().enhance_by_fields()

        adhoc_filters = AdHocFilters.from_request(
            request, user_field_names=user_field_names
        )
        if adhoc_filters.has_any_filters:
            queryset = adhoc_filters.apply_to_queryset(model, queryset)

        search = query_params.get("search")
        if search:
            queryset = queryset.search_all_fields(
                search, search_mode=query_params.get("search_mode")
            )

        result = aggregate(
            model,
            queryset,
            TableFields(model, user_field_names),
            group_by=query_params.get("group_by"),
            aggregations=query_params.get("aggregations"),
            order_by=query_params.get("order_by"),
            limit=limit,
            offset=query_params.get("offset") or 0,
            ignore_unknown_group_by=query_params.get("unknown_group_by") == "ignore",
        )
        if query_params.get("with_fields"):
            result["fields"] = list_table_fields(request, table)
        return Response(result)

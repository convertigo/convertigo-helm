class C8oAggregateError(Exception):
    """Base class of the errors of this plugin, mapped to a 400 by the view."""

    error = "ERROR_C8O_AGGREGATE"


class InvalidParameter(C8oAggregateError):
    """A query parameter cannot be parsed."""

    error = "ERROR_C8O_AGGREGATE_INVALID_PARAMETER"


class FieldNotFound(C8oAggregateError):
    """A field reference does not match any field of the table."""

    error = "ERROR_C8O_AGGREGATE_FIELD_NOT_FOUND"


class GroupByNotSupported(C8oAggregateError):
    """The field cannot be used in `group_by`."""

    error = "ERROR_C8O_AGGREGATE_GROUP_BY_NOT_SUPPORTED"


class AggregationNotSupported(C8oAggregateError):
    """The aggregation does not exist, or does not apply to the field."""

    error = "ERROR_C8O_AGGREGATE_AGGREGATION_NOT_SUPPORTED"


class InvalidOrderBy(C8oAggregateError):
    """`order_by` names something that is neither a group key nor an alias."""

    error = "ERROR_C8O_AGGREGATE_INVALID_ORDER_BY"

"""
Ad hoc group by and aggregations on a Baserow table.

Everything runs in one SQL query: `values(*group_columns).annotate(...)`, on the
queryset that Baserow itself builds for the rows endpoint (same filters, same
search). The aggregation expressions come from `view_aggregation_type_registry`,
the registry behind the footer aggregations of the grid view, so a `sum` here is
exactly the `sum` Baserow computes.
"""

import json
import math
import re
from dataclasses import dataclass, field as dataclass_field
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple, Union

from django.contrib.postgres.aggregates import ArrayAgg
from django.db.models import (
    Aggregate,
    Count,
    DecimalField,
    F,
    Max,
    Min,
    Q,
    QuerySet,
    Window,
)
from django.db.models.functions import RowNumber

from baserow.contrib.database.views.exceptions import AggregationTypeDoesNotExist
from baserow.contrib.database.views.models import DEFAULT_SORT_TYPE_KEY
from baserow.contrib.database.views.registries import view_aggregation_type_registry
from baserow.contrib.database.views.utils import (
    AnnotatedAggregation,
    DistributionAggregation,
)

from .exceptions import (
    AggregationNotSupported,
    FieldNotFound,
    GroupByNotSupported,
    InvalidOrderBy,
    InvalidParameter,
)

# Fields that hold one scalar value per row, grouped by their value.
GROUP_BY_FIELD_TYPES = (
    "text",
    "number",
    "boolean",
    "date",
    "single_select",
    "rating",
    "autonumber",
    "email",
    "url",
)
# Formula fields are accepted when they return one of these types (never an array).
GROUP_BY_FORMULA_TYPES = ("text", "char", "number", "boolean", "date")
# Lookups are grouped by their whole array of items ([{"id": ..., "value": ...}]):
# two rows are in the same group when their arrays are equal (same items, in the
# same order), an empty array being a group of its own.
LOOKUP = "lookup"
# The min and max of these fields are written as the rows endpoint writes their cells
# (a date without time, the time with its microseconds...).
DATE_FIELD_TYPES = ("date", "last_modified", "created_on")

AGGREGATION_TYPE_ALIASES = {"avg": "average"}
COUNT = "count"
ROW_ID = "id"
ROW_ORDER = "order"
FIRST = "first"
FIELD_ID_PATTERN = re.compile(r"^(?:field_)?([0-9]+)$")
# the number of values of a distribution, as Baserow gives them in the footer of a grid
DISTRIBUTION_LIMIT = 10


def split_list_param(value: Optional[str], name: str) -> List[str]:
    """
    Splits a list parameter: comma separated, or a JSON array of strings when an item
    contains a comma (`["Ville, pays", "sum:Montant"]`).
    """

    value = (value or "").strip()
    if not value:
        return []
    if value.startswith("["):
        try:
            items = json.loads(value)
        except ValueError:
            raise InvalidParameter(
                f"`{name}` starts with '[' but is not a valid JSON array."
            )
        if not isinstance(items, list) or not all(
            isinstance(item, str) or (isinstance(item, int) and item is not True)
            for item in items
        ):
            raise InvalidParameter(f"`{name}` must be a JSON array of strings.")
        items = [str(item) for item in items]
    else:
        items = value.split(",")
    return [item.strip() for item in items if item.strip()]


class TableFields:
    """Resolves the field references of the request on the fields of the model."""

    def __init__(self, model, user_field_names: bool):
        self.user_field_names = user_field_names
        self.by_id = {}
        self.by_name = {}
        for field_object in model._field_objects.values():
            self.by_id[field_object["field"].id] = field_object
            self.by_name[field_object["field"].name] = field_object

    def resolve(self, reference: str, param: str) -> Dict[str, Any]:
        """
        A reference is a field id (`12` or `field_12`) or a field name. With
        `user_field_names` the name wins over the id, without it the id wins.
        """

        match = FIELD_ID_PATTERN.match(reference)
        by_id = self.by_id.get(int(match.group(1))) if match else None
        by_name = self.by_name.get(reference)
        found = (by_name or by_id) if self.user_field_names else (by_id or by_name)
        if found is None:
            raise FieldNotFound(
                f"`{param}`: the field '{reference}' does not exist in this table."
            )
        return found

    def key(self, field) -> str:
        """The key of the field in the response, like the rows endpoint."""

        return field.name if self.user_field_names else f"field_{field.id}"


@dataclass
class GroupKey:
    key: str
    field_object: Dict[str, Any]
    options: Dict[int, Any] = dataclass_field(default_factory=dict)
    serializer_field: Any = None

    @property
    def field(self):
        return self.field_object["field"]

    @property
    def field_type(self):
        return self.field_object["type"]

    @property
    def db_column(self) -> str:
        return self.field.db_column


@dataclass
class Aggregation:
    alias: str
    type: str
    field_object: Optional[Dict[str, Any]] = None
    # `id` or `order` of the rows themselves instead of a field: min/max of it, or
    # first:id, the id of the first row of the group in the order of the table
    row_field: Optional[str] = None
    # the serializer of the cells of the field, for the min and max of a date
    serializer_field: Any = None


def check_can_group_by(field, field_type):
    """
    Raises GroupByNotSupported unless the field holds one scalar value per row and
    Baserow itself can group by it, or is a lookup (grouped by its array of items).
    """

    supported_types = ", ".join(GROUP_BY_FIELD_TYPES + (LOOKUP,))
    formula_types = ", ".join(GROUP_BY_FORMULA_TYPES)
    if field_type.type == LOOKUP:
        # The items of a lookup are stored in a jsonb array column, which Postgres
        # compares (and groups) item by item, in order. A lookup in error has no
        # usable value.
        supported = field_type.to_baserow_formula_type(field).type == "array"
    elif field_type.type == "formula":
        formula_type = field_type.to_baserow_formula_type(field).type
        if formula_type not in GROUP_BY_FORMULA_TYPES:
            raise GroupByNotSupported(
                f'The formula field "{field.name}" returns a value of type '
                f"{formula_type}: only formulas returning {formula_types} can be "
                "grouped by."
            )
        supported = field_type.check_can_group_by(field, DEFAULT_SORT_TYPE_KEY)
    elif field_type.type == "autonumber":
        # Baserow never groups a grid view by an autonumber, a value unique to each
        # row, but it is a plain integer column that SQL groups like any other.
        supported = True
    elif field_type.type in GROUP_BY_FIELD_TYPES:
        supported = field_type.check_can_group_by(field, DEFAULT_SORT_TYPE_KEY)
    else:
        supported = False
    if not supported:
        raise GroupByNotSupported(
            f'The field "{field.name}" of type {field_type.type} cannot be grouped '
            f"by. Supported types: {supported_types}, and formulas returning "
            f"{formula_types}. The other fields holding several values per row "
            "(link_row, multiple_select, array formulas...) are not supported."
        )


def parse_group_by(
    param: Optional[str], fields: TableFields, ignore_unknown: bool = False
) -> Tuple[List[GroupKey], List[str]]:
    """
    Returns the group keys, and the references that do not exist in the table when
    `ignore_unknown` drops them instead of refusing them: such a reference is a
    constant, the same (absent) value for every row, so it splits nothing.
    """

    group_keys, ignored = [], []
    for reference in split_list_param(param, "group_by"):
        try:
            field_object = fields.resolve(reference, "group_by")
        except FieldNotFound:
            if not ignore_unknown:
                raise
            ignored.append(reference)
            continue
        field, field_type = field_object["field"], field_object["type"]
        if any(g.field.id == field.id for g in group_keys):
            raise InvalidParameter(f'`group_by` names the field "{field.name}" twice.')
        check_can_group_by(field, field_type)
        group_key = GroupKey(key=fields.key(field), field_object=field_object)
        if field_type.type == "single_select":
            group_key.options = {o.id: o for o in field.select_options.all()}
        else:
            # For a lookup, the serializer of the rows endpoint: the group value is
            # the array exactly as a row of the group gives it.
            group_key.serializer_field = field_type.get_response_serializer_field(field)
        group_keys.append(group_key)
    return group_keys, ignored


def parse_aggregation(raw: str, fields: TableFields) -> Aggregation:
    """
    Parses `type:field`, `alias=type:field`, `count` or `alias=count`. The alias of
    an aggregation without one is the text of the request (`sum:Montant`).
    """

    alias, expression = None, raw
    head, separator, tail = raw.partition("=")
    if separator and ":" not in head:
        alias, expression = head.strip(), tail.strip()
        if not alias:
            raise InvalidParameter(f"The aggregation '{raw}' has an empty alias.")

    type_name, _, reference = expression.partition(":")
    type_name = type_name.strip().lower()
    type_name = AGGREGATION_TYPE_ALIASES.get(type_name, type_name)
    reference = reference.strip()

    if type_name == COUNT:
        if reference:
            raise AggregationNotSupported(
                "`count` counts the rows of each group and takes no field: use "
                "`not_empty_count:<field>` to count the non empty values of a field."
            )
        return Aggregation(alias=alias or COUNT, type=COUNT)

    if (type_name in ("min", "max") and reference in (ROW_ID, ROW_ORDER)) or (
        type_name == FIRST and reference == ROW_ID
    ):
        # the first (or last) row of each group, e.g. to read a row of it or to order
        # the groups like the rows of the table (order, then id)
        return Aggregation(
            alias=alias or raw.strip(), type=type_name, row_field=reference
        )

    try:
        aggregation_type = view_aggregation_type_registry.get(type_name)
    except AggregationTypeDoesNotExist:
        available = ", ".join(
            [COUNT, "avg"]
            + sorted(
                t for t in view_aggregation_type_registry.get_types() if t != COUNT
            )
        )
        raise AggregationNotSupported(
            f"Unknown aggregation '{type_name}'. Available: {available}."
        )
    if not reference:
        raise InvalidParameter(
            f"The aggregation '{raw}' needs a field: `{type_name}:<field>`."
        )

    field_object = fields.resolve(reference, "aggregations")
    field = field_object["field"]
    if not aggregation_type.field_is_compatible(field):
        raise AggregationNotSupported(
            f'The aggregation {type_name} does not apply to the field "{field.name}" '
            f"of type {field_object['type'].type}."
        )
    aggregation = Aggregation(
        alias=alias or raw.strip(), type=type_name, field_object=field_object
    )
    if type_name in ("min", "max") and is_date_field(field, field_object["type"]):
        aggregation.serializer_field = field_object[
            "type"
        ].get_response_serializer_field(field)
    return aggregation


def is_date_field(field, field_type) -> bool:
    if field_type.type == "formula":
        return field_type.to_baserow_formula_type(field).type == "date"
    return field_type.type in DATE_FIELD_TYPES


def parse_aggregations(
    param: Optional[str], fields: TableFields, group_keys: List[GroupKey]
) -> List[Aggregation]:
    """The row count of each group always comes first, under `count`."""

    aggregations = [Aggregation(alias=COUNT, type=COUNT)]
    taken = {g.key for g in group_keys}
    if COUNT in taken:
        raise InvalidParameter(
            "A group_by field is named `count`, which is the key of the row count: "
            "use the field id, or user_field_names=false."
        )
    taken.add(COUNT)
    for raw in split_list_param(param, "aggregations"):
        aggregation = parse_aggregation(raw, fields)
        if aggregation.alias == COUNT and aggregation.type == COUNT:
            continue
        if aggregation.alias in taken:
            raise InvalidParameter(
                f"The key '{aggregation.alias}' is used twice in the response: give "
                "the aggregation another alias with `alias=type:field`."
            )
        taken.add(aggregation.alias)
        aggregations.append(aggregation)
    return aggregations


def without_nan(expression, db_column: str, model_field):
    """
    Leaves the NaN of a number column out of its aggregates, as lib_BaseRow does with
    the cells it reads from the rows endpoint (written "NaN"). A NaN in a group made
    its sum, average, min or max NaN, which JSON cannot carry: the request failed (500)
    instead of answering. A formula holds one when it multiplies by
    `tonumber('')`, for instance.
    """

    decimal_field = getattr(model_field, "expression_field", model_field)
    if not isinstance(decimal_field, DecimalField):
        return expression
    if isinstance(expression, dict):
        return {
            key: without_nan(sub_expression, db_column, model_field)
            for key, sub_expression in expression.items()
        }
    if not isinstance(expression, Aggregate):
        return expression
    expression = expression.copy()
    finite = ~Q(**{db_column: Decimal("NaN")})
    expression.filter = (
        finite if expression.filter is None else expression.filter & finite
    )
    return expression


def json_number(value):
    """An aggregate JSON cannot write (NaN, an infinity) is answered as no value."""

    if isinstance(value, (float, Decimal)) and not math.isfinite(value):
        return None
    return value


@dataclass
class AggregationQuery:
    pre_annotations: Dict[str, Any] = dataclass_field(default_factory=dict)
    annotations: Dict[str, Any] = dataclass_field(default_factory=dict)
    # alias -> annotation name, or {sub key -> annotation name} for a dict aggregate
    names: Dict[str, Union[str, Dict[str, str]]] = dataclass_field(default_factory=dict)
    distributions: Dict[str, DistributionAggregation] = dataclass_field(
        default_factory=dict
    )
    # aliases of first:id, whose annotation is the ordered list of the ids
    firsts: set = dataclass_field(default_factory=set)
    # aliases of min/max:order, answered as the decimal text Baserow gives for order
    row_orders: set = dataclass_field(default_factory=set)
    # alias -> serializer of the cells, for the min and max of a date
    cell_serializers: Dict[str, Any] = dataclass_field(default_factory=dict)


def build_aggregation_query(model, aggregations: List[Aggregation]) -> AggregationQuery:
    query = AggregationQuery()
    for index, aggregation in enumerate(aggregations):
        # Internal names: an alias may clash with a column of the model (`id`,
        # `field_12`) or contain characters SQL aliases do not accept.
        name = f"c8o_agg_{index}"
        if aggregation.type == COUNT:
            query.annotations[name] = Count("id", distinct=True)
            query.names[aggregation.alias] = name
            continue
        if aggregation.row_field:
            if aggregation.type == FIRST:
                # the rows of a table are read in the order (order, id)
                query.annotations[name] = ArrayAgg("id", ordering=("order", "id"))
                query.firsts.add(aggregation.alias)
            else:
                query.annotations[name] = (Min if aggregation.type == "min" else Max)(
                    aggregation.row_field
                )
                if aggregation.row_field == ROW_ORDER:
                    query.row_orders.add(aggregation.alias)
            query.names[aggregation.alias] = name
            continue

        field = aggregation.field_object["field"]
        db_column = field.db_column
        model_field = model._meta.get_field(db_column)
        aggregation_type = view_aggregation_type_registry.get(aggregation.type)
        expression = aggregation_type.get_aggregation(db_column, model_field, field)
        expression = without_nan(expression, db_column, model_field)

        if isinstance(expression, AnnotatedAggregation):
            # Some aggregations need per row annotations first (empty counts of
            # many to many fields).
            query.pre_annotations.update(expression.annotations)
            query.annotations[name] = expression.aggregation
            query.names[aggregation.alias] = name
        elif isinstance(expression, DistributionAggregation):
            query.distributions[aggregation.alias] = expression
        elif isinstance(expression, dict):
            query.names[aggregation.alias] = {}
            for sub_key, sub_expression in expression.items():
                query.annotations[f"{name}_{sub_key}"] = sub_expression
                query.names[aggregation.alias][sub_key] = f"{name}_{sub_key}"
        else:
            query.annotations[name] = expression
            query.names[aggregation.alias] = name
            if aggregation.serializer_field is not None:
                query.cell_serializers[aggregation.alias] = aggregation.serializer_field
    return query


def parse_order_by(
    param: Optional[str],
    group_keys: List[GroupKey],
    query: AggregationQuery,
    fields: TableFields,
    ignored: Tuple[str, ...] = (),
) -> List[Any]:
    """
    `order_by=-sum:Montant,Statut`: a group key or an alias, `-` for descending.
    A group key sorts like Baserow sorts the field (a single select by its value, a
    lookup by its array). The group keys always close the ordering, so that pages
    are stable. The `ignored` group_by references, constant, sort nothing.
    """

    def group_expression(group_key: GroupKey):
        return group_key.field_type.get_sortable_column_expression(
            group_key.field, group_key.db_column, DEFAULT_SORT_TYPE_KEY
        )

    ordering = []
    for item in split_list_param(param, "order_by"):
        descending = item.startswith("-")
        key = item[1:].strip() if item[0] in "+-" else item
        if key in ignored and key not in query.names:
            continue
        name = query.names.get(key)
        if isinstance(name, str):
            expression = F(name)
        elif name is not None:
            raise InvalidOrderBy(f"`order_by`: '{key}' returns several values.")
        else:
            group_key = next((g for g in group_keys if g.key == key), None)
            if group_key is None:
                try:
                    field_id = fields.resolve(key, "order_by")["field"].id
                except FieldNotFound:
                    field_id = None
                group_key = next(
                    (g for g in group_keys if g.field.id == field_id), None
                )
            if group_key is None:
                available = [g.key for g in group_keys] + [
                    alias for alias, n in query.names.items() if isinstance(n, str)
                ]
                raise InvalidOrderBy(
                    f"`order_by`: '{key}' is neither a group_by field nor an "
                    f"aggregation alias. Available: {', '.join(available)}."
                )
            expression = group_expression(group_key)
        if not hasattr(expression, "desc"):
            expression = F(expression)
        ordering.append(expression.desc() if descending else expression.asc())

    if not ordering:
        ordering = [group_expression(g).asc() for g in group_keys]
    ordering += [F(g.db_column).asc() for g in group_keys]
    return ordering


def format_group_value(group_key: GroupKey, value):
    if value is None:
        return None
    if group_key.field_type.type == "single_select":
        option = group_key.options.get(value)
        return {
            "id": value,
            "value": option.value if option else None,
            "color": option.color if option else None,
        }
    try:
        return group_key.serializer_field.to_representation(value)
    except Exception:  # noqa: BLE001 the raw value is still a usable key
        return value


def format_row(row: Dict[str, Any], group_keys, query: AggregationQuery):
    result = {g.key: format_group_value(g, row[g.db_column]) for g in group_keys}
    for alias, name in query.names.items():
        if isinstance(name, dict):
            result[alias] = {
                sub_key: json_number(row[n]) for sub_key, n in name.items()
            }
        elif alias in query.firsts:
            result[alias] = row[name][0] if row[name] else None
        elif alias in query.row_orders and row[name] is not None:
            result[alias] = str(row[name])
        elif alias in query.cell_serializers and row[name] is not None:
            result[alias] = query.cell_serializers[alias].to_representation(row[name])
        else:
            result[alias] = json_number(row[name])
    return result


def group_distributions(
    queryset: QuerySet,
    group_keys: List[GroupKey],
    distribution: DistributionAggregation,
) -> Dict[str, List[Dict[str, Any]]]:
    """
    The distribution of each group in one query: the top values of the group by
    count, then by value, as DistributionAggregation.calculate gives them for the
    whole queryset. Keyed by the JSON of the raw group values (a lookup is a list).
    """

    columns = [g.db_column for g in group_keys]
    queryset = queryset.all()
    # as DistributionAggregation.calculate: no prefetch of the multiple fields
    queryset._multi_field_prefetch_related_funcs = []
    ranked = (
        queryset.values(*columns, distribution.group_by)
        .annotate(c8o_count=Count("*"))
        .annotate(
            c8o_rank=Window(
                RowNumber(),
                partition_by=[F(column) for column in columns],
                order_by=[F("c8o_count").desc(), F(distribution.group_by).asc()],
            )
        )
        .filter(c8o_rank__lte=DISTRIBUTION_LIMIT)
        .order_by(*columns, "c8o_rank")
    )
    distributions = {}
    for row in ranked:
        key = distribution_group_key(row, columns)
        distributions.setdefault(key, []).append(
            {"value": row[distribution.group_by], "count": row["c8o_count"]}
        )
    return distributions


def distribution_group_key(row: Dict[str, Any], columns: List[str]) -> str:
    return json.dumps([row[column] for column in columns], sort_keys=True, default=str)


def aggregate(
    model,
    queryset: QuerySet,
    fields: TableFields,
    group_by: Optional[str],
    aggregations: Optional[str],
    order_by: Optional[str],
    limit: int,
    offset: int,
    ignore_unknown_group_by: bool = False,
) -> Dict[str, Any]:
    """
    Groups the filtered `queryset` and computes the aggregations of each group.
    Without group_by the whole queryset is one group. `count` in the response is the
    number of groups, for paging with limit and offset.

    With `ignore_unknown_group_by`, the group_by references that match no field of
    the table are dropped: the groups have no key for them, and when none is left
    the whole queryset is one group, none when it has no rows.
    """

    group_keys, ignored = parse_group_by(
        group_by, fields, ignore_unknown=ignore_unknown_group_by
    )
    parsed = parse_aggregations(aggregations, fields, group_keys)
    query = build_aggregation_query(model, parsed)
    ordering = parse_order_by(order_by, group_keys, query, fields, tuple(ignored))

    if query.pre_annotations:
        queryset = queryset.annotate(**query.pre_annotations)

    if group_keys:
        grouped = queryset.values(*[g.db_column for g in group_keys]).annotate(
            **query.annotations
        )
        total = grouped.count()
        rows = list(grouped.order_by(*ordering)[offset : offset + limit])
    elif ignored and not queryset.exists():
        # grouped by fields the table does not have: the rows make one group, and no rows make no group, as a
        # grouping of the rows does (without group_by an empty queryset is still one group)
        total = 0
        rows = []
    else:
        total = 1
        rows = [queryset.aggregate(**query.annotations)] if offset == 0 else []

    results = [format_row(row, group_keys, query) for row in rows]
    if results and query.distributions:
        for alias, distribution in query.distributions.items():
            if group_keys:
                by_group = group_distributions(queryset, group_keys, distribution)
                columns = [g.db_column for g in group_keys]
                for row, result in zip(rows, results):
                    result[alias] = by_group.get(
                        distribution_group_key(row, columns), []
                    )
            else:
                results[0][alias] = [
                    {"value": value, "count": count}
                    for value, count in distribution.calculate(queryset.all())
                ]

    return {"count": total, "limit": limit, "offset": offset, "results": results}

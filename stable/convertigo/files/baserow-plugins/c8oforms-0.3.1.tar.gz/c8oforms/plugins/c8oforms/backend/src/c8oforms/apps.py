from django.apps import AppConfig

from baserow.core.registries import plugin_registry


class C8oFormsConfig(AppConfig):
    name = "c8oforms"

    def ready(self):
        from .plugins import C8oFormsPlugin

        plugin_registry.register(C8oFormsPlugin())

        # Backports of Baserow performance fixes, each one only installed on the
        # versions that do not ship it and unless turned off.
        from .select_perf import install as install_select_perf

        install_select_perf()

from typing import Tuple

from baserow.version import VERSION


def baserow_version() -> Tuple[int, ...]:
    """The running Baserow version, e.g. (1, 34, 5)."""

    return tuple(int(part) for part in VERSION.split(".")[:3] if part.isdigit())


def baserow_is_before(*version: int) -> bool:
    """
    True when the running Baserow is older than `version`: a backport is only
    installed on the versions that do not ship the change themselves.
    """

    return baserow_version() < version

import os

FEATURES = ("aggregate", "select_perf", "response_memory")


def setup(settings):
    """
    Called by Baserow after its own settings are loaded and before Django starts.
    """

    # A feature can be turned off without redeploying the plugin, e.g.
    # BASEROW_C8O_DISABLE_AGGREGATE=true removes /api/c8o/aggregate/ and
    # BASEROW_C8O_DISABLE_SELECT_PERF=true keeps the Baserow code as it is.
    disabled = {
        feature
        for feature in FEATURES
        if os.getenv(f"BASEROW_C8O_DISABLE_{feature.upper()}", "").lower()
        in ("1", "true", "yes", "on")
    }
    # `settings` writes to the Django settings but does not read back what it
    # wrote: keep using the local `disabled`.
    settings.C8O_DISABLED_FEATURES = disabled

    _install_response_memory(settings, disabled)

    # aggregate: number of groups returned when the request gives no `limit`.
    settings.C8O_AGGREGATE_DEFAULT_LIMIT = int(
        os.getenv("BASEROW_C8O_AGGREGATE_DEFAULT_LIMIT", "200")
    )
    # aggregate: highest `limit` a request may ask for. Above it the request is
    # refused with a 400, it is never silently truncated: the client pages with
    # `offset`.
    settings.C8O_AGGREGATE_MAX_LIMIT = int(
        os.getenv("BASEROW_C8O_AGGREGATE_MAX_LIMIT", "5000")
    )


def _install_response_memory(settings, disabled):
    """
    The JSON renderer of Baserow 2.3.3 becomes the default DRF renderer, on the
    Baserow versions that do not have it yet.
    """

    from c8oforms.compat import baserow_is_before
    from c8oforms.response_memory import RENDERER, UPSTREAM_VERSION

    renderers = settings.REST_FRAMEWORK.get("DEFAULT_RENDERER_CLASSES", ())
    if (
        "response_memory" in disabled
        or not baserow_is_before(*UPSTREAM_VERSION)
        or tuple(renderers) != ("rest_framework.renderers.JSONRenderer",)
    ):
        # Turned off, shipped by Baserow itself, or the renderers were customized:
        # leave them alone.
        return
    settings.REST_FRAMEWORK["DEFAULT_RENDERER_CLASSES"] = (RENDERER,)

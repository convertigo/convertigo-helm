from django.conf import settings
from django.urls import include, path

from baserow.core.registries import Plugin


def get_features():
    """
    The features of the plugin that serve endpoints: (name, urls module). Each one
    is mounted under /api/c8o/<name>/ unless BASEROW_C8O_DISABLE_<NAME>=true. The
    other features (select_perf, response_memory) change no route.
    """

    from .aggregate.api import urls as aggregate_urls

    return [("aggregate", aggregate_urls)]


class C8oFormsPlugin(Plugin):
    type = "c8oforms"

    def get_api_urls(self):
        disabled = getattr(settings, "C8O_DISABLED_FEATURES", set())
        return [
            path(
                "c8o/",
                include(
                    (
                        [
                            path(f"{name}/", include(urls, namespace=name))
                            for name, urls in get_features()
                            if name not in disabled
                        ],
                        "c8oforms",
                    ),
                    namespace=self.type,
                ),
            )
        ]

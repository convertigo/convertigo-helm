"""
Less memory per API response: a backport of the JSON renderer Baserow ships from
2.3.3 (commit bc3dd53, "reduce backend memory usage by releasing each API response
memory after request is sent"). Set as the default DRF renderer by the settings of
the plugin on Baserow < 2.3.3 unless BASEROW_C8O_DISABLE_RESPONSE_MEMORY=true.

The ASGI handler part of that commit is not backported: it only concerns the
backend-asgi processes, and the 1.34 ASGI setup differs.
"""

UPSTREAM_VERSION = (2, 3, 3)
RENDERER = "c8oforms.response_memory.renderers.BaserowJSONRenderer"

"""
Faster row reads for tables with many single or multiple select fields: a backport
of the change Baserow ships from 2.3.0 (commit 06375e3, "perf: faster grid/row reads
for tables with many select fields"). Installed at startup on Baserow < 2.3.0 unless
BASEROW_C8O_DISABLE_SELECT_PERF=true.
"""

from django.conf import settings

from loguru import logger

from ..compat import baserow_is_before

UPSTREAM_VERSION = (2, 3, 0)

_originals = {}


def is_enabled() -> bool:
    return "select_perf" not in getattr(
        settings, "C8O_DISABLED_FEATURES", set()
    ) and baserow_is_before(*UPSTREAM_VERSION)


def install():
    """Replaces the slow Baserow code with the backport, once."""

    if _originals or not is_enabled():
        return

    from baserow.contrib.database.api.fields import serializers as field_serializers
    from baserow.core import db as core_db

    from . import backport

    prefetch_class = core_db.CombinedForeignKeyAndManyToManyMultipleFieldPrefetch
    select_option_serializer = field_serializers.SelectOptionSerializer
    _originals.update(
        set_prefetched_values_on_result_set=(
            prefetch_class.__dict__["set_prefetched_values_on_result_set"]
        ),
        collect_many_to_many_key_target_ids=(
            prefetch_class.__dict__["collect_many_to_many_key_target_ids"]
        ),
        meta=select_option_serializer.__dict__.get("Meta"),
    )

    prefetch_class.set_prefetched_values_on_result_set = (
        backport.set_prefetched_values_on_result_set
    )
    prefetch_class.collect_many_to_many_key_target_ids = (
        backport.collect_many_to_many_key_target_ids
    )
    select_option_serializer.Meta = backport.SelectOptionSerializerMeta
    logger.info("c8oforms: select_perf installed (backport of Baserow 2.3.0)")


def uninstall():
    """Puts the Baserow code back, for the tests."""

    if not _originals:
        return

    from baserow.contrib.database.api.fields import serializers as field_serializers
    from baserow.core import db as core_db

    prefetch_class = core_db.CombinedForeignKeyAndManyToManyMultipleFieldPrefetch
    prefetch_class.set_prefetched_values_on_result_set = _originals[
        "set_prefetched_values_on_result_set"
    ]
    prefetch_class.collect_many_to_many_key_target_ids = _originals[
        "collect_many_to_many_key_target_ids"
    ]
    if _originals["meta"] is None:
        del field_serializers.SelectOptionSerializer.Meta
    else:
        field_serializers.SelectOptionSerializer.Meta = _originals["meta"]
    _originals.clear()


def is_installed() -> bool:
    return bool(_originals)

"""
Backport of Baserow 2.3.0 commit 06375e3 ("perf: faster grid/row reads for tables
with many select fields", https://github.com/baserow/baserow/pull/5550) onto the
1.34.x code it was written against: the two methods below are the ones of
`baserow.core.db.CombinedForeignKeyAndManyToManyMultipleFieldPrefetch` in 1.34.5
with that commit applied, and replace them at startup (see `install`).

Copyright (c) 2019-present Baserow B.V., MIT Expat license (Baserow core). Only the
module layout differs from the upstream code.
"""

from django.db import connection
from django.db.models import ForeignKey, ManyToManyField

from rest_framework import serializers

from baserow.core.psycopg import sql


class _PrefetchedManyToManyResult:
    """
    Stand-in stored in a row's prefetch cache for a many-to-many relation.

    Iterating it returns the already resolved instances without touching the
    database. Any queryset operation (`filter`, `order_by`, `values_list`, ...)
    lazily builds the real `pk__in` scoped queryset, so a consumer that re-queries
    the relation still gets the correct rows. This avoids building a queryset per
    row and field up front, which dominates the request time for tables with many
    many-to-many fields.

    The lazy queryset uses the default manager so re-querying applies the same
    filters (e.g. trash filtering) as the resolved instances, which come from the
    default manager too.
    """

    __slots__ = ("_target_model", "_target_ids", "_result_cache")

    def __init__(self, target_model, target_ids, result_cache):
        self._target_model = target_model
        self._target_ids = target_ids
        self._result_cache = result_cache

    def _build_queryset(self):
        qs = self._target_model._default_manager.filter(pk__in=self._target_ids or [])
        qs._result_cache = self._result_cache
        qs._prefetch_done = True
        return qs

    def all(self):
        return self

    def __iter__(self):
        return iter(self._result_cache)

    def __len__(self):
        return len(self._result_cache)

    def __bool__(self):
        return bool(self._result_cache)

    def __getitem__(self, item):
        return self._result_cache[item]

    def __getattr__(self, name):
        return getattr(self._build_queryset(), name)


def set_prefetched_values_on_result_set(
    self,
    queryset,
    row_id_to_field_name_to_target_ids: dict,
    result_set: list,
    target_instances: dict,
) -> list:
    """
    Sets the prefetched instances on the result set of the queryset. It will
    figure out if the original field was a foreign key or a many to many field,
    and will apply the instances accordingly.

    :param queryset: The queryset that is being resolved.
    :param row_id_to_field_name_to_target_ids: A mapping that contains which id
        in the target model belongs to which row and field id.
    :param result_set: The fetched `result_set` where the prefetched results must
        be added to. This also contains the foreign key ids.
    :param target_instances: The fetched target instances that must be applied to
        the `result_set`.
    :return: The updated `result_set` containing all the prefetched instances.
    """

    # Resolve the model field for each prefetched field name once instead of
    # for every row. With many fields this is called row_count * field_count
    # times otherwise.
    model_meta = queryset.model._meta
    model_fields = {
        field_name: model_meta.get_field(field_name) for field_name in self.field_names
    }

    for result in result_set:
        field_name_to_target_ids = row_id_to_field_name_to_target_ids[result.id]
        for field_name in self.field_names:
            model_field = model_fields[field_name]
            target_ids = field_name_to_target_ids.get(field_name)

            if isinstance(model_field, ForeignKey) and target_ids is not None:
                target_id = target_ids[0]
                target_instance = target_instances.get(target_id)
                setattr(result, field_name, target_instance)

            if isinstance(model_field, ManyToManyField):
                # The related instances are already fully resolved in
                # `target_instances`, so store a lazy stand-in that iterates them
                # directly and only builds a real queryset if a consumer re-filters
                # or re-orders the relation. See `_PrefetchedManyToManyResult`.
                result_cache = (
                    [
                        target_instances.get(target_id)
                        for target_id in target_ids
                        # The target may have been deleted while the relationship
                        # still exists; don't put `None` in the result set.
                        if target_id in target_instances
                    ]
                    if target_ids
                    else []
                )
                result._prefetched_objects_cache = getattr(
                    result, "_prefetched_objects_cache", {}
                )
                result._prefetched_objects_cache[
                    field_name
                ] = _PrefetchedManyToManyResult(
                    self.target_model, target_ids, result_cache
                )

    return result_set


def collect_many_to_many_key_target_ids(
    self, queryset, result_set, row_id_to_field_name_to_target_ids
):
    """
    Loops over all already fetched rows of the original queryset, and collects the
    many to many ids of the provided `field_names`. Even though each many to many
    field has its own through table, it's combined into multiple union queries,
    send to the server as one query.

    :param queryset: The queryset that is being resolved.
    :param result_set: The fetched `result_set` where the prefetched results must
        be added to. This also contains the foreign key ids.
    :param row_id_to_field_name_to_target_ids: A mapping that contains which id
        in the target model belongs to which row and field id.
    :return: An updated mapping, now also containing the many to many ids.
    """

    sub_queries = []

    for field_name in self.field_names:
        model_field = queryset.model._meta.get_field(field_name)

        if not isinstance(model_field, ManyToManyField):
            continue

        through_model = model_field.remote_field.through
        through_table_name = through_model._meta.db_table
        through_fields = through_model._meta.get_fields()
        row_column_name = through_fields[1].get_attname_column()[1]
        target_column_name = through_fields[2].get_attname_column()[1]

        if (
            not self.skip_target_check
            and through_fields[2].remote_field.model is not self.target_model
        ):
            raise ValueError(
                f"The related model of {field_name} is not equal to the target "
                f"model {self.target_model}."
            )

        # The row ids are filtered through the `wanted_rows` CTE below instead of
        # being repeated in every subquery, which keeps the query small even with
        # hundreds of many-to-many fields.
        subquery = sql.SQL(
            """
            (
                SELECT
                    id,
                    {field_name} as field_name,
                    {row_id_column} as row_id,
                    {target_id_column} as target_id_column
                FROM {m2m_table}
                WHERE {row_id_column} IN (SELECT row_id FROM wanted_rows)
            )
            """
        ).format(
            field_name=sql.Literal(field_name),
            m2m_table=sql.Identifier(through_table_name),
            row_id_column=sql.Identifier(row_column_name),
            target_id_column=sql.Identifier(target_column_name),
        )
        sub_queries.append(subquery)

    if len(sub_queries) > 0 and len(result_set) > 0:
        wanted_rows = sql.SQL(", ").join(
            sql.SQL("({})").format(sql.Literal(result.id)) for result in result_set
        )
        union_query = sql.SQL(" UNION ").join(sub_queries)
        union_sql = sql.SQL(
            """
            WITH wanted_rows (row_id) AS (VALUES {wanted_rows})
            SELECT
                row_id,
                field_name,
                ARRAY_AGG(target_id_column ORDER BY id)
            FROM ({union_query}) sub
            GROUP BY row_id, field_name
            """
        ).format(wanted_rows=wanted_rows, union_query=union_query)

        with connection.cursor() as cursor:
            cursor.execute(union_sql)
            results = cursor.fetchall()

        for result in results:
            # 0=row_id, 1=field_name, 2=target ids
            row_id_to_field_name_to_target_ids[result[0]][result[1]] = result[2]

    return row_id_to_field_name_to_target_ids


class PrefetchedManyToManyListSerializer(serializers.ListSerializer):
    """
    Reads a many-to-many relation straight from the instance's prefetch cache
    instead of going through `getattr(instance, field)`, which builds a Django
    `ManyRelatedManager` for every row. For wide tables serialized in bulk this
    manager creation dominates the response time. Falls back to the default
    lookup when the relation wasn't prefetched.

    Use as `Meta.list_serializer_class` on a serializer used with `many=True`.
    """

    def get_attribute(self, instance):
        prefetched = getattr(instance, "_prefetched_objects_cache", None)
        if prefetched is not None and len(self.source_attrs) == 1:
            cached = prefetched.get(self.source_attrs[0])
            if cached is not None:
                return cached
        return super().get_attribute(instance)


class SelectOptionSerializerMeta:
    # Read prefetched options directly when serializing rows in bulk.
    list_serializer_class = PrefetchedManyToManyListSerializer

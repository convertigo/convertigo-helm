import json
from datetime import date, datetime, timezone
from decimal import Decimal

from django.shortcuts import reverse
from django.test.utils import override_settings

import pytest
from rest_framework.status import (
    HTTP_200_OK,
    HTTP_400_BAD_REQUEST,
    HTTP_401_UNAUTHORIZED,
    HTTP_404_NOT_FOUND,
)

from baserow.contrib.database.fields.handler import FieldHandler
from baserow.contrib.database.rows.handler import RowHandler
from baserow.contrib.database.tokens.handler import TokenHandler


def url(table_id):
    return reverse("api:c8oforms:aggregate:table", kwargs={"table_id": table_id})


@pytest.fixture
def sales(data_fixture):
    """
    A table of 5 sales:

    | Ville | Statut | Montant | Payé  |
    | Paris | Ouvert | 10.50   | true  |
    | Paris | Ouvert | 20.00   | false |
    | Lyon  | Fermé  | 5.00    | true  |
    | Lyon  |        |         | false |
    | Paris | Fermé  | 100.00  | true  |
    """

    user, jwt_token = data_fixture.create_user_and_token()
    table = data_fixture.create_database_table(user=user, name="Ventes")
    ville = data_fixture.create_text_field(table=table, name="Ville", primary=True)
    statut = data_fixture.create_single_select_field(table=table, name="Statut")
    ouvert = data_fixture.create_select_option(
        field=statut, value="Ouvert", color="blue", order=0
    )
    ferme = data_fixture.create_select_option(
        field=statut, value="Fermé", color="red", order=1
    )
    montant = data_fixture.create_number_field(
        table=table, name="Montant", number_decimal_places=2
    )
    paye = data_fixture.create_boolean_field(table=table, name="Payé")

    model = table.get_model()
    for v, s, m, p in [
        ("Paris", ouvert, Decimal("10.50"), True),
        ("Paris", ouvert, Decimal("20.00"), False),
        ("Lyon", ferme, Decimal("5.00"), True),
        ("Lyon", None, None, False),
        ("Paris", ferme, Decimal("100.00"), True),
    ]:
        model.objects.create(
            **{
                ville.db_column: v,
                statut.db_column: s,
                montant.db_column: m,
                paye.db_column: p,
            }
        )

    return {
        "user": user,
        "jwt": jwt_token,
        "table": table,
        "ville": ville,
        "statut": statut,
        "montant": montant,
        "paye": paye,
        "ouvert": ouvert,
        "ferme": ferme,
    }


def get(api_client, sales, token=None, **params):
    return api_client.get(
        url(sales["table"].id),
        params,
        HTTP_AUTHORIZATION=token or f"JWT {sales['jwt']}",
    )


@pytest.mark.django_db
def test_group_by_with_aggregations(api_client, sales):
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        aggregations="sum:Montant,avg:Montant,min:Montant,max:Montant,"
        "unique_count:Statut",
        order_by="-sum:Montant",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    data = response.json()
    assert data["count"] == 2
    assert data["results"] == [
        {
            "Ville": "Paris",
            "count": 3,
            "sum:Montant": 130.5,
            "avg:Montant": 43.5,
            "min:Montant": 10.5,
            "max:Montant": 100.0,
            "unique_count:Statut": 2,
        },
        {
            "Ville": "Lyon",
            "count": 2,
            "sum:Montant": 5.0,
            "avg:Montant": 5.0,
            "min:Montant": 5.0,
            "max:Montant": 5.0,
            "unique_count:Statut": 1,
        },
    ]


@pytest.mark.django_db
def test_single_select_groups_give_id_and_value(api_client, sales):
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Statut,Ville",
        aggregations="sum:Montant",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    ouvert, ferme = sales["ouvert"], sales["ferme"]
    # Sorted on the option value, like Baserow sorts a single select; the empty
    # option comes last.
    assert response.json()["results"] == [
        {
            "Statut": {"id": ferme.id, "value": "Fermé", "color": "red"},
            "Ville": "Lyon",
            "count": 1,
            "sum:Montant": 5.0,
        },
        {
            "Statut": {"id": ferme.id, "value": "Fermé", "color": "red"},
            "Ville": "Paris",
            "count": 1,
            "sum:Montant": 100.0,
        },
        {
            "Statut": {"id": ouvert.id, "value": "Ouvert", "color": "blue"},
            "Ville": "Paris",
            "count": 2,
            "sum:Montant": 30.5,
        },
        {"Statut": None, "Ville": "Lyon", "count": 1, "sum:Montant": None},
    ]


@pytest.mark.django_db
def test_several_aggregations_on_the_same_field_with_aliases(api_client, sales):
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Payé",
        aggregations="total=sum:Montant,moyenne=avg:Montant,sum:Montant,"
        "vides=empty_count:Montant",
        order_by="Payé",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["results"] == [
        {
            "Payé": False,
            "count": 2,
            "total": 20.0,
            "moyenne": 20.0,
            "sum:Montant": 20.0,
            "vides": 1,
        },
        {
            "Payé": True,
            "count": 3,
            "total": 115.5,
            "moyenne": 38.5,
            "sum:Montant": 115.5,
            "vides": 0,
        },
    ]


@pytest.mark.django_db
def test_field_ids_without_user_field_names(api_client, sales):
    ville, montant = sales["ville"], sales["montant"]
    response = get(
        api_client,
        sales,
        group_by=f"field_{ville.id}",
        aggregations=f"sum:{montant.id}",
        order_by=f"field_{ville.id}",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["results"] == [
        {f"field_{ville.id}": "Lyon", "count": 2, f"sum:{montant.id}": 5.0},
        {f"field_{ville.id}": "Paris", "count": 3, f"sum:{montant.id}": 130.5},
    ]


@pytest.mark.django_db
def test_distinct_is_a_group_by_without_aggregation(api_client, sales):
    response = get(api_client, sales, user_field_names="true", group_by="Ville")
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["results"] == [
        {"Ville": "Lyon", "count": 2},
        {"Ville": "Paris", "count": 3},
    ]


@pytest.mark.django_db
def test_without_group_by_the_whole_table_is_one_group(api_client, sales):
    response = get(
        api_client,
        sales,
        user_field_names="true",
        aggregations="sum:Montant,distribution:Ville",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json() == {
        "count": 1,
        "limit": 200,
        "offset": 0,
        "results": [
            {
                "count": 5,
                "sum:Montant": 135.5,
                "distribution:Ville": [
                    {"value": "Paris", "count": 3},
                    {"value": "Lyon", "count": 2},
                ],
            }
        ],
    }


@pytest.mark.django_db
def test_footer_aggregations_on_the_whole_table_and_by_group(
    api_client, data_fixture, sales
):
    # what lib_BaseRow asks for the aggregations of the footer of a Baserow grid
    quand = data_fixture.create_date_field(table=sales["table"], name="Quand")
    model = sales["table"].get_model()
    for row, day in zip(model.objects.order_by("id"), [3, 1, 9, None, 5]):
        setattr(row, quand.db_column, None if day is None else date(2024, 1, day))
        row.save()
    aggregations = (
        "empty=empty_count:Montant,filled=not_empty_count:Montant,"
        "unique=unique_count:Statut,checked=not_empty_count:Payé,"
        "unchecked=empty_count:Payé,median=median:Montant,std=std_dev:Montant,"
        "var=variance:Montant,earliest=min:Quand,latest=max:Quand,"
        "no_status=empty_count:Statut"
    )

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="[]",
        aggregations=aggregations,
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["count"] == 1
    [summary] = response.json()["results"]
    assert summary == {
        "count": 5,
        "empty": 1,
        "filled": 4,
        "unique": 2,
        "checked": 3,
        "unchecked": 2,
        "median": pytest.approx(15.25),
        "std": pytest.approx(38.552521),
        "var": pytest.approx(1486.296875),
        "earliest": "2024-01-01",
        "latest": "2024-01-09",
        "no_status": 1,
    }

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        aggregations=aggregations,
        order_by="Ville",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    lyon, paris = response.json()["results"]
    assert (lyon["count"], lyon["empty"], lyon["filled"], lyon["median"]) == (
        2,
        1,
        1,
        5.0,
    )
    assert (lyon["checked"], lyon["unchecked"], lyon["earliest"]) == (
        1,
        1,
        "2024-01-09",
    )
    assert (paris["count"], paris["empty"], paris["unique"], paris["median"]) == (
        3,
        0,
        2,
        20.0,
    )
    assert (paris["earliest"], paris["latest"], paris["no_status"]) == (
        "2024-01-01",
        "2024-01-05",
        0,
    )

    # an empty table is still one summary row, as the footer of Baserow
    model.objects.all().delete()
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="[]",
        aggregations=aggregations + ",distribution:Ville",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    [summary] = response.json()["results"]
    assert (summary["count"], summary["empty"], summary["median"]) == (0, 0, None)
    assert summary["distribution:Ville"] == []


@pytest.mark.django_db
def test_min_and_max_of_dates_are_the_cells_of_the_rows_endpoint(
    api_client, data_fixture, sales
):
    # lib_BaseRow takes them as the value of a cell of the column
    table = sales["table"]
    jour = data_fixture.create_date_field(table=table, name="Jour")
    heure = data_fixture.create_date_field(
        table=table, name="Heure", date_include_time=True
    )
    # a last modified and a created on without time: their cells are dates
    FieldHandler().create_field(sales["user"], table, "last_modified", name="Modifié")
    FieldHandler().create_field(sales["user"], table, "created_on", name="Créé")
    model = table.get_model()
    for index, row in enumerate(model.objects.order_by("id")):
        setattr(row, jour.db_column, date(2024, 1 + index, 3))
        setattr(
            row,
            heure.db_column,
            datetime(2024, 5, 1, 8, index * 7, 0, index * 123457, tzinfo=timezone.utc),
        )
        row.save()

    response = api_client.get(
        reverse("api:database:rows:list", kwargs={"table_id": table.id}),
        {"user_field_names": "true", "size": 200},
        HTTP_AUTHORIZATION=f"JWT {sales['jwt']}",
    )
    FieldHandler().create_field(
        sales["user"], table, "formula", name="Formule", formula="field('Heure')"
    )
    response = api_client.get(
        reverse("api:database:rows:list", kwargs={"table_id": table.id}),
        {"user_field_names": "true", "size": 200},
        HTTP_AUTHORIZATION=f"JWT {sales['jwt']}",
    )
    cells = response.json()["results"]
    for name in ("Jour", "Heure", "Modifié", "Créé", "Formule"):
        values = sorted(row[name] for row in cells if row[name] is not None)
        for group_by in ("[]", "Payé"):
            response = get(
                api_client,
                sales,
                user_field_names="true",
                group_by=group_by,
                aggregations=f"a=min:{name},b=max:{name}",
            )
            assert response.status_code == HTTP_200_OK, response.json()
            results = response.json()["results"]
            assert min(r["a"] for r in results) == values[0], name
            assert max(r["b"] for r in results) == values[-1], name
            assert all(r["a"] in values and r["b"] in values for r in results), name


@pytest.mark.django_db
def test_the_nan_of_a_number_formula_are_left_out_of_its_aggregates(
    api_client, data_fixture, sales
):
    # tonumber of a text that is not a number is NaN: the two unpaid sales (Paris 20.00
    # and Lyon without amount) are NaN, the rows endpoint writes them "NaN" and
    # lib_BaseRow leaves them out of the aggregates it computes from the rows. A NaN in
    # a group failed the request (500, JSON cannot carry NaN).
    table = sales["table"]
    FieldHandler().create_field(
        sales["user"],
        table,
        "formula",
        name="Encaissé",
        formula="if(field('Payé'), field('Montant'), field('Montant') * tonumber('x'))",
    )
    response = api_client.get(
        reverse("api:database:rows:list", kwargs={"table_id": table.id}),
        {"user_field_names": "true", "size": 200},
        HTTP_AUTHORIZATION=f"JWT {sales['jwt']}",
    )
    cells = [row["Encaissé"] for row in response.json()["results"]]
    assert sorted(float(cell) for cell in cells if cell != "NaN") == [5, 10.5, 100]
    assert cells.count("NaN") == 2

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        aggregations="s=sum:Encaissé,a=avg:Encaissé,lo=min:Encaissé,hi=max:Encaissé,"
        "me=median:Encaissé,sd=std_dev:Encaissé,va=variance:Encaissé",
        order_by="Ville",
    )
    assert response.status_code == HTTP_200_OK, response.content
    paris, lyon = sorted(
        response.json()["results"], key=lambda r: r["Ville"] != "Paris"
    )
    assert (paris["s"], paris["a"], paris["lo"], paris["hi"]) == (
        110.5,
        55.25,
        10.5,
        100.0,
    )
    assert paris["me"] == 55.25
    # the standard deviation and the variance of the population, as in Baserow
    assert paris["sd"] == pytest.approx(44.75)
    assert paris["va"] == pytest.approx(2002.5625)
    assert (lyon["s"], lyon["a"], lyon["lo"], lyon["hi"]) == (5.0, 5.0, 5.0, 5.0)

    # without group by, and a group whose every value is NaN has no value
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="[]",
        aggregations="s=sum:Encaissé,hi=max:Encaissé",
    )
    assert response.status_code == HTTP_200_OK, response.content
    assert response.json()["results"] == [{"count": 5, "s": 115.5, "hi": 100.0}]
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Payé",
        aggregations="s=sum:Encaissé,a=avg:Encaissé",
        filter__Payé__boolean="false",
    )
    assert response.status_code == HTTP_200_OK, response.content
    assert response.json()["results"] == [
        {"Payé": False, "count": 2, "s": None, "a": None}
    ]


@pytest.mark.django_db
def test_distribution_of_each_group(api_client, sales):
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        aggregations="distribution:Statut,montants=distribution:Montant",
        order_by="Ville",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    # the top values of each group by count, then by value, the empty one last
    assert response.json()["results"] == [
        {
            "Ville": "Lyon",
            "count": 2,
            "distribution:Statut": [
                {"value": "Fermé", "count": 1},
                {"value": None, "count": 1},
            ],
            "montants": [{"value": 5.0, "count": 1}, {"value": None, "count": 1}],
        },
        {
            "Ville": "Paris",
            "count": 3,
            "distribution:Statut": [
                {"value": "Ouvert", "count": 2},
                {"value": "Fermé", "count": 1},
            ],
            "montants": [
                {"value": 10.5, "count": 1},
                {"value": 20.0, "count": 1},
                {"value": 100.0, "count": 1},
            ],
        },
    ]

    # grouped by a single select, the empty option included; the page only
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Statut",
        aggregations="distribution:Ville,distribution:Payé",
        limit=2,
    )
    assert response.status_code == HTTP_200_OK, response.json()
    data = response.json()
    assert data["count"] == 3
    assert [
        (g["Statut"]["value"], g["distribution:Ville"], g["distribution:Payé"])
        for g in data["results"]
    ] == [
        (
            "Fermé",
            [{"value": "Lyon", "count": 1}, {"value": "Paris", "count": 1}],
            [{"value": True, "count": 2}],
        ),
        (
            "Ouvert",
            [{"value": "Paris", "count": 2}],
            [{"value": False, "count": 1}, {"value": True, "count": 1}],
        ),
    ]
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Statut",
        aggregations="distribution:Ville",
        offset=2,
    )
    assert response.json()["results"] == [
        {
            "Statut": None,
            "count": 1,
            "distribution:Ville": [{"value": "Lyon", "count": 1}],
        }
    ]


@pytest.mark.django_db
def test_distribution_of_each_group_keeps_its_ten_top_values(api_client, sales):
    model = sales["table"].get_model()
    montant, ville = sales["montant"].db_column, sales["ville"].db_column
    for value in list(range(12)) + [11]:
        model.objects.create(**{ville: "Nice", montant: Decimal(value)})

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        aggregations="distribution:Montant",
        **{"filter__Ville__equal": "Nice"},
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["results"] == [
        {
            "Ville": "Nice",
            "count": 13,
            "distribution:Montant": [{"value": 11.0, "count": 2}]
            + [{"value": float(value), "count": 1} for value in range(9)],
        }
    ]


@pytest.mark.django_db
def test_distribution_of_each_lookup_group(api_client, data_fixture, sales):
    user, table = sales["user"], sales["table"]
    link, lookup, (dupont, martin) = add_lookup(
        data_fixture, user, table, ["Dupont", "Martin"]
    )
    model = table.get_model()
    rows = list(model.objects.order_by("id"))
    links = [[dupont, martin], [dupont, martin], [dupont], [dupont], []]
    RowHandler().update_rows(
        user,
        table,
        [{"id": r.id, link.db_column: ids} for r, ids in zip(rows, links)],
        model=model,
    )

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Noms",
        aggregations="distribution:Ville",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    results = {json.dumps(g["Noms"]): g for g in response.json()["results"]}
    pair = [{"id": dupont, "value": "Dupont"}, {"id": martin, "value": "Martin"}]
    assert results[json.dumps(pair)]["distribution:Ville"] == [
        {"value": "Paris", "count": 2}
    ]
    assert results[json.dumps([{"id": dupont, "value": "Dupont"}])][
        "distribution:Ville"
    ] == [{"value": "Lyon", "count": 2}]
    assert results[json.dumps([])]["distribution:Ville"] == [
        {"value": "Paris", "count": 1}
    ]


@pytest.mark.django_db
def test_simple_filters_and_search(api_client, sales):
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        aggregations="sum:Montant",
        **{"filter__Payé__boolean": "1"},
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["results"] == [
        {"Ville": "Lyon", "count": 1, "sum:Montant": 5.0},
        {"Ville": "Paris", "count": 2, "sum:Montant": 110.5},
    ]

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        filter_type="OR",
        **{"filter__Montant__higher_than": "50", "filter__Ville__equal": "Lyon"},
    )
    assert response.json()["results"] == [
        {"Ville": "Lyon", "count": 2},
        {"Ville": "Paris", "count": 1},
    ]

    response = get(
        api_client, sales, user_field_names="true", group_by="Ville", search="Lyon"
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["results"] == [{"Ville": "Lyon", "count": 2}]


@pytest.mark.django_db
def test_grouped_filters_json(api_client, sales):
    filters = {
        "filter_type": "AND",
        "filters": [
            {
                "type": "single_select_equal",
                "field": "Statut",
                "value": str(sales["ouvert"].id),
            }
        ],
        "groups": [],
    }
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        aggregations="sum:Montant",
        filters=json.dumps(filters),
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["results"] == [
        {"Ville": "Paris", "count": 2, "sum:Montant": 30.5}
    ]


@pytest.mark.django_db
def test_limit_offset_and_cap(api_client, sales):
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville,Statut",
        order_by="-count,Ville",
        limit=2,
        offset=1,
    )
    assert response.status_code == HTTP_200_OK, response.json()
    data = response.json()
    assert data["count"] == 4
    assert data["limit"] == 2
    assert data["offset"] == 1
    assert [(r["Ville"], r["count"]) for r in data["results"]] == [
        ("Lyon", 1),
        ("Lyon", 1),
    ]

    with override_settings(C8O_AGGREGATE_MAX_LIMIT=3):
        response = get(api_client, sales, group_by="Ville", limit=4)
    assert response.status_code == HTTP_400_BAD_REQUEST
    assert response.json()["error"] == "ERROR_C8O_AGGREGATE_INVALID_PARAMETER"


@pytest.mark.django_db
def test_group_by_refuses_multi_value_fields(api_client, data_fixture, sales):
    user, table = sales["user"], sales["table"]
    clients = data_fixture.create_database_table(
        user=user, database=table.database, name="Clients"
    )
    data_fixture.create_text_field(table=clients, name="Nom", primary=True)
    FieldHandler().create_field(
        user, table, "link_row", name="Clients", link_row_table=clients
    )
    data_fixture.create_multiple_select_field(table=table, name="Tags")
    FieldHandler().create_field(
        user, table, "formula", name="Liste", formula="field('Clients')"
    )
    FieldHandler().create_field(
        user, table, "formula", name="Code", formula="concat(field('Ville'), '-X')"
    )

    for name in ["Clients", "Tags", "Liste"]:
        response = get(api_client, sales, user_field_names="true", group_by=name)
        assert response.status_code == HTTP_400_BAD_REQUEST, name
        assert response.json()["error"] == (
            "ERROR_C8O_AGGREGATE_GROUP_BY_NOT_SUPPORTED"
        )
        assert name in response.json()["detail"]

    # A formula returning a text is a scalar: it can be grouped by.
    response = get(api_client, sales, user_field_names="true", group_by="Code")
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["results"] == [
        {"Code": "Lyon-X", "count": 2},
        {"Code": "Paris-X", "count": 3},
    ]


@pytest.mark.django_db
def test_parameter_errors(api_client, sales):
    cases = [
        ({"group_by": "Inconnu"}, "ERROR_C8O_AGGREGATE_FIELD_NOT_FOUND"),
        (
            {"aggregations": "sum:Ville"},
            "ERROR_C8O_AGGREGATE_AGGREGATION_NOT_SUPPORTED",
        ),
        (
            {"aggregations": "foo:Montant"},
            "ERROR_C8O_AGGREGATE_AGGREGATION_NOT_SUPPORTED",
        ),
        (
            {"aggregations": "count:Montant"},
            "ERROR_C8O_AGGREGATE_AGGREGATION_NOT_SUPPORTED",
        ),
        (
            {"group_by": "Ville", "aggregations": "distribution:Payé,distribution:x"},
            "ERROR_C8O_AGGREGATE_FIELD_NOT_FOUND",
        ),
        ({"aggregations": "sum"}, "ERROR_C8O_AGGREGATE_INVALID_PARAMETER"),
        (
            {"aggregations": "x=sum:Montant,x=avg:Montant"},
            "ERROR_C8O_AGGREGATE_INVALID_PARAMETER",
        ),
        (
            {"group_by": "Ville", "order_by": "Montant"},
            "ERROR_C8O_AGGREGATE_INVALID_ORDER_BY",
        ),
        ({"group_by": "[Ville"}, "ERROR_C8O_AGGREGATE_INVALID_PARAMETER"),
        ({"group_by": "{Ville}"}, "ERROR_C8O_AGGREGATE_FIELD_NOT_FOUND"),
    ]
    for params, error in cases:
        response = get(api_client, sales, user_field_names="true", **params)
        assert response.status_code == HTTP_400_BAD_REQUEST, params
        assert response.json()["error"] == error, (params, response.json())

    # A JSON array for the names that contain a comma.
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by='["Ville"]',
        aggregations='["total=sum:Montant"]',
    )
    assert response.status_code == HTTP_200_OK, response.json()


@pytest.mark.django_db
def test_permissions(api_client, data_fixture, sales):
    table = sales["table"]

    response = api_client.get(url(table.id), {"group_by": "Ville"})
    assert response.status_code == HTTP_401_UNAUTHORIZED

    response = api_client.get(url(999999), HTTP_AUTHORIZATION=f"JWT {sales['jwt']}")
    assert response.status_code == HTTP_404_NOT_FOUND
    assert response.json()["error"] == "ERROR_TABLE_DOES_NOT_EXIST"

    _, other_jwt = data_fixture.create_user_and_token()
    response = get(api_client, sales, token=f"JWT {other_jwt}")
    assert response.status_code == HTTP_400_BAD_REQUEST
    assert response.json()["error"] == "ERROR_USER_NOT_IN_GROUP"

    workspace = table.database.workspace
    token = TokenHandler().create_token(sales["user"], workspace, "read")
    response = get(
        api_client,
        sales,
        token=f"Token {token.key}",
        user_field_names="true",
        group_by="Ville",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert len(response.json()["results"]) == 2

    no_read = TokenHandler().create_token(sales["user"], workspace, "no read")
    TokenHandler().update_token_permissions(
        sales["user"], no_read, True, False, True, True
    )
    response = get(api_client, sales, token=f"Token {no_read.key}")
    assert response.status_code == HTTP_401_UNAUTHORIZED
    assert response.json()["error"] == "ERROR_NO_PERMISSION_TO_TABLE"


@pytest.mark.django_db
def test_min_and_max_of_the_row_id(api_client, sales):
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        aggregations="first=min:id,last=max:id",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    model = sales["table"].get_model()
    ville = sales["ville"].db_column
    for group in response.json()["results"]:
        ids = sorted(
            model.objects.filter(**{ville: group["Ville"]}).values_list("id", flat=True)
        )
        assert (group["first"], group["last"]) == (ids[0], ids[-1])


@pytest.mark.django_db
def test_with_fields_gives_the_fields_of_the_fields_endpoint(api_client, sales):
    response = get(api_client, sales, user_field_names="true", group_by="Ville")
    assert response.status_code == HTTP_200_OK, response.json()
    assert "fields" not in response.json()

    response = get(
        api_client, sales, user_field_names="true", group_by="Ville", with_fields="true"
    )
    assert response.status_code == HTTP_200_OK, response.json()
    fields = api_client.get(
        reverse("api:database:fields:list", kwargs={"table_id": sales["table"].id}),
        HTTP_AUTHORIZATION=f"JWT {sales['jwt']}",
    )
    assert fields.status_code == HTTP_200_OK
    assert response.json()["fields"] == fields.json()
    assert len(response.json()["results"]) == 2

    # a token that may read the rows but nothing else still lists the fields, as the
    # fields endpoint allows it
    workspace = sales["table"].database.workspace
    token = TokenHandler().create_token(sales["user"], workspace, "read only")
    TokenHandler().update_token_permissions(
        sales["user"], token, False, True, False, False
    )
    response = get(
        api_client,
        sales,
        token=f"Token {token.key}",
        group_by="Ville",
        user_field_names="true",
        with_fields="true",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["fields"] == fields.json()


@pytest.mark.django_db
def test_first_row_and_order_of_each_group_follow_the_order_of_the_table(
    api_client, sales
):
    # moved rows: the first row of a group in the table order is no longer its smallest id
    model = sales["table"].get_model()
    ville = sales["ville"].db_column
    paris = list(model.objects.filter(**{ville: "Paris"}).order_by("id"))
    paris[-1].order = Decimal("0.50000000000000000000")
    paris[-1].save()

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Ville",
        aggregations="first=first:id,top=min:order,bottom=max:order,low=min:id",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    for group in response.json()["results"]:
        rows = list(
            model.objects.filter(**{ville: group["Ville"]}).order_by("order", "id")
        )
        assert group["first"] == rows[0].id
        assert group["top"] == str(rows[0].order)
        assert group["bottom"] == str(rows[-1].order)
        assert group["low"] == min(r.id for r in rows)
    paris_group = next(g for g in response.json()["results"] if g["Ville"] == "Paris")
    assert paris_group["first"] == paris[-1].id != paris_group["low"]
    assert paris_group["top"] == "0.50000000000000000000"

    response = get(api_client, sales, group_by="Ville", aggregations="first:order")
    assert response.status_code == HTTP_400_BAD_REQUEST


def add_lookup(data_fixture, user, table, names):
    """
    Adds to `table` a link_row "Clients" to a new table of clients named `names`,
    and the lookup "Noms" of their name. Returns (link field, lookup field, ids).
    """

    clients = data_fixture.create_database_table(
        user=user, database=table.database, name=f"Clients {table.id}"
    )
    nom = data_fixture.create_text_field(table=clients, name="Nom", primary=True)
    client_model = clients.get_model()
    ids = [client_model.objects.create(**{nom.db_column: n}).id for n in names]
    link = FieldHandler().create_field(
        user, table, "link_row", name="Clients", link_row_table=clients
    )
    lookup = FieldHandler().create_field(
        user,
        table,
        "lookup",
        name="Noms",
        through_field_id=link.id,
        target_field_id=nom.id,
    )
    return link, lookup, ids


def groups_of_the_rows_endpoint(api_client, sales, key):
    """Groups the rows of the rows endpoint like the library: on the JSON of a cell."""

    response = api_client.get(
        reverse("api:database:rows:list", kwargs={"table_id": sales["table"].id}),
        {"user_field_names": "true", "size": 200},
        HTTP_AUTHORIZATION=f"JWT {sales['jwt']}",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    rows = response.json()["results"]
    groups = {}
    for row in rows:
        groups.setdefault(json.dumps(row[key]), []).append(row)
    return {row["id"]: row for row in rows}, groups


@pytest.mark.django_db
def test_group_by_lookup_groups_on_the_whole_array(api_client, data_fixture, sales):
    user, table = sales["user"], sales["table"]
    # two clients with the same name: their arrays differ by the id of the row
    link, lookup, (dupont, martin, dupont_bis) = add_lookup(
        data_fixture, user, table, ["Dupont", "Martin", "Dupont"]
    )
    model = table.get_model()
    rows = list(model.objects.order_by("id"))
    links = [[dupont, martin], [dupont, martin], [dupont_bis], [dupont], []]
    RowHandler().update_rows(
        user,
        table,
        [{"id": r.id, link.db_column: ids} for r, ids in zip(rows, links)],
        model=model,
    )

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Noms",
        aggregations="sum:Montant,first=first:id,top=min:order",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    data = response.json()
    assert data["count"] == 4

    by_id, expected = groups_of_the_rows_endpoint(api_client, sales, "Noms")
    assert len(expected) == 4
    results = {json.dumps(g["Noms"]): g for g in data["results"]}
    assert results.keys() == expected.keys()
    for key, group in results.items():
        members = expected[key]
        assert group["count"] == len(members)
        # the group value is the cell of a row of the group, as the rows endpoint
        # gives it
        assert group["Noms"] == by_id[group["first"]]["Noms"]
        assert group["first"] == members[0]["id"]
        assert group["top"] == members[0]["order"]
    assert results[json.dumps([])]["count"] == 1
    assert results[json.dumps([])]["sum:Montant"] == 100.0
    pair = [{"id": dupont, "value": "Dupont"}, {"id": martin, "value": "Martin"}]
    assert results[json.dumps(pair)]["count"] == 2
    assert results[json.dumps(pair)]["sum:Montant"] == 30.5
    assert results[json.dumps([{"id": dupont, "value": "Dupont"}])]["count"] == 1
    assert results[json.dumps([{"id": dupont_bis, "value": "Dupont"}])]["count"] == 1

    # with another key, by id, ordered by the lookup then descending count
    response = get(
        api_client,
        sales,
        group_by=f"field_{lookup.id},field_{sales['ville'].id}",
        order_by=f"field_{lookup.id},-count",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["count"] == 4
    assert sum(g["count"] for g in response.json()["results"]) == 5


@pytest.mark.django_db
def test_group_by_lookup_counts_every_row_of_a_big_table(api_client, data_fixture):
    user, jwt_token = data_fixture.create_user_and_token()
    table = data_fixture.create_database_table(user=user, name="Grande")
    data_fixture.create_text_field(table=table, name="Nom", primary=True)
    montant = data_fixture.create_number_field(table=table, name="Montant")
    link, lookup, (a, b, c) = add_lookup(data_fixture, user, table, ["A", "B", "C"])
    patterns = [[a], [a, b], [], [c]]
    model = table.get_model()
    RowHandler().create_rows(
        user,
        table,
        rows_values=[
            {link.db_column: patterns[i % 4], montant.db_column: i % 7}
            for i in range(1500)
        ],
        model=model,
    )
    assert model.objects.count() == 1500
    sales = {"table": table, "jwt": jwt_token}

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Noms",
        aggregations="sum:Montant,first=first:id,top=min:order",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    data = response.json()
    assert data["count"] == 4
    results = {json.dumps(g["Noms"]): g for g in data["results"]}
    ordered = list(model.objects.order_by("order", "id"))
    names = {a: "A", b: "B", c: "C"}
    for index, pattern in enumerate(patterns):
        value = [{"id": i, "value": names[i]} for i in pattern]
        group = results[json.dumps(value)]
        members = ordered[index::4]
        assert group["count"] == len(members) == 375
        assert group["sum:Montant"] == sum(
            getattr(r, montant.db_column) for r in members
        )
        assert group["first"] == members[0].id
        assert group["top"] == str(members[0].order)
    assert sum(g["count"] for g in data["results"]) == 1500


@pytest.mark.django_db
def test_group_by_refuses_a_lookup_in_error(api_client, data_fixture, sales):
    user, table = sales["user"], sales["table"]
    link, lookup, _ = add_lookup(data_fixture, user, table, ["Dupont"])
    FieldHandler().delete_field(user, link)

    response = get(api_client, sales, user_field_names="true", group_by="Noms")
    assert response.status_code == HTTP_400_BAD_REQUEST, response.json()
    assert response.json()["error"] == "ERROR_C8O_AGGREGATE_GROUP_BY_NOT_SUPPORTED"


@pytest.mark.django_db
def test_unknown_group_by_ignore_drops_the_unknown_references(api_client, sales):
    # without the option, or with the default, an unknown reference is refused
    for params in [{}, {"unknown_group_by": "error"}]:
        response = get(
            api_client,
            sales,
            user_field_names="true",
            group_by="Ville,Inconnu",
            **params,
        )
        assert response.status_code == HTTP_400_BAD_REQUEST, params
        assert response.json()["error"] == "ERROR_C8O_AGGREGATE_FIELD_NOT_FOUND"
        assert "Inconnu" in response.json()["detail"]

    response = get(api_client, sales, group_by="Ville", unknown_group_by="maybe")
    assert response.status_code == HTTP_400_BAD_REQUEST
    assert response.json()["error"] == "ERROR_QUERY_PARAMETER_VALIDATION"

    # mixed: the known keys group, the unknown one is absent from the groups (and
    # sorts nothing in order_by)
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Inconnu,Ville",
        aggregations="sum:Montant",
        order_by="Inconnu,-sum:Montant",
        unknown_group_by="ignore",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["count"] == 2
    assert response.json()["results"] == [
        {"Ville": "Paris", "count": 3, "sum:Montant": 130.5},
        {"Ville": "Lyon", "count": 2, "sum:Montant": 5.0},
    ]

    # a known key is still checked
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Inconnu,Ville,Ville",
        unknown_group_by="ignore",
    )
    assert response.json()["error"] == "ERROR_C8O_AGGREGATE_INVALID_PARAMETER"


@pytest.mark.django_db
def test_unknown_group_by_ignore_only_unknown_is_one_group(api_client, sales):
    model = sales["table"].get_model()
    ville = sales["ville"].db_column
    paris = list(model.objects.filter(**{ville: "Paris"}).order_by("id"))
    paris[-1].order = Decimal("0.50000000000000000000")
    paris[-1].save()

    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Inconnu,field_999999",
        aggregations="sum:Montant,first=first:id,top=min:order",
        unknown_group_by="ignore",
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json() == {
        "count": 1,
        "limit": 200,
        "offset": 0,
        "results": [
            {
                "count": 5,
                "sum:Montant": 135.5,
                "first": paris[-1].id,
                "top": "0.50000000000000000000",
            }
        ],
    }

    # over the filtered rows only
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Inconnu",
        aggregations="sum:Montant,first=first:id",
        unknown_group_by="ignore",
        **{"filter__Ville__equal": "Lyon"},
    )
    assert response.status_code == HTTP_200_OK, response.json()
    lyon = list(model.objects.filter(**{ville: "Lyon"}).order_by("order", "id"))
    assert response.json()["results"] == [
        {"count": 2, "sum:Montant": 5.0, "first": lyon[0].id}
    ]


@pytest.mark.django_db
def test_unknown_group_by_ignore_no_rows_is_no_group(api_client, sales):
    # the grouping of no rows makes no group, as the reading of the rows does
    response = get(
        api_client,
        sales,
        user_field_names="true",
        group_by="Inconnu",
        aggregations="first=first:id",
        unknown_group_by="ignore",
        **{"filter__Ville__equal": "Nulle part"},
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json() == {"count": 0, "limit": 200, "offset": 0, "results": []}

    # without group_by an empty table is still one group
    response = get(
        api_client,
        sales,
        user_field_names="true",
        aggregations="first=first:id",
        **{"filter__Ville__equal": "Nulle part"},
    )
    assert response.status_code == HTTP_200_OK, response.json()
    assert response.json()["count"] == 1

from django.test.utils import override_settings

from c8oforms.plugins import C8oFormsPlugin


def mounted_features():
    (c8o,) = C8oFormsPlugin().get_api_urls()
    assert str(c8o.pattern) == "c8o/"
    return [str(feature.pattern) for feature in c8o.url_patterns]


def test_every_feature_is_mounted_by_default():
    assert mounted_features() == ["aggregate/"]


@override_settings(C8O_DISABLED_FEATURES={"aggregate"})
def test_a_feature_can_be_disabled():
    assert mounted_features() == []

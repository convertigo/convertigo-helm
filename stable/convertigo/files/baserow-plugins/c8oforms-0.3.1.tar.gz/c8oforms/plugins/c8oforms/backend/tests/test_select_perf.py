"""
The first two tests are the ones of Baserow 2.3.0 for this change
(backend/tests/baserow/core/test_core_db.py, commit 06375e3), run against the
backport. Copyright (c) 2019-present Baserow B.V., MIT Expat license.
"""

from django.shortcuts import reverse

import pytest

from baserow.contrib.database.fields.models import SelectOption
from baserow.contrib.database.rows.handler import RowHandler
from baserow.core.db import CombinedForeignKeyAndManyToManyMultipleFieldPrefetch
from c8oforms import select_perf
from c8oforms.compat import baserow_is_before
from c8oforms.select_perf import backport

BACKPORTED = select_perf.is_enabled()
# Without the backport, 1.x does not have the change these tests cover.
SHIPS_THE_CHANGE = BACKPORTED or not baserow_is_before(*select_perf.UPSTREAM_VERSION)
needs_the_change = pytest.mark.skipif(
    not SHIPS_THE_CHANGE, reason="select_perf turned off on a Baserow without it"
)


def test_the_backport_is_installed_only_before_baserow_2_3_0():
    method = CombinedForeignKeyAndManyToManyMultipleFieldPrefetch.__dict__[
        "set_prefetched_values_on_result_set"
    ]
    assert select_perf.is_installed() is BACKPORTED
    assert (method is backport.set_prefetched_values_on_result_set) is BACKPORTED
    if not baserow_is_before(*select_perf.UPSTREAM_VERSION):
        assert not BACKPORTED


@needs_the_change
@pytest.mark.django_db
def test_combined_prefetch_query_count_is_constant_with_many_fields(
    data_fixture, django_assert_num_queries
):
    """
    The prefetch must resolve in a fixed number of queries (fetch rows, fetch the
    many-to-many relations, fetch the target instances) regardless of how many
    fields and rows are involved, and accessing the prefetched cells must not issue
    additional queries. This guards against re-introducing per-cell queryset work in
    `set_prefetched_values_on_result_set`.
    """

    user = data_fixture.create_user()
    table = data_fixture.create_database_table(name="Wide", user=user)

    multiple_select_fields = []
    first_option_per_field = {}
    for i in range(5):
        field = data_fixture.create_multiple_select_field(
            table=table, name=f"option_field_{i}", order=i
        )
        options = [
            data_fixture.create_select_option(
                field=field, value=v, color="blue", order=o
            )
            for o, v in enumerate(["A", "B", "C"])
        ]
        multiple_select_fields.append(field)
        first_option_per_field[field.id] = options[0]

    handler = RowHandler()
    handler.create_rows(
        user=user,
        table=table,
        rows_values=[
            {
                f"field_{field.id}": [first_option_per_field[field.id].id]
                for field in multiple_select_fields
            }
            for _ in range(5)
        ],
    )

    model = table.get_model()
    prefetch = CombinedForeignKeyAndManyToManyMultipleFieldPrefetch(
        SelectOption, skip_target_check=True
    ).add_field_names([f"field_{field.id}" for field in multiple_select_fields])

    # One query for the rows, one for the many-to-many relations, one for the
    # select options. The field and row counts must not change this.
    with django_assert_num_queries(3):
        rows = list(model.objects.all().multi_field_prefetch(prefetch))

    # Reading every prefetched cell must not trigger any additional query.
    with django_assert_num_queries(0):
        for row in rows:
            for field in multiple_select_fields:
                assert [
                    option.id for option in getattr(row, f"field_{field.id}").all()
                ] == [first_option_per_field[field.id].id]


@needs_the_change
@pytest.mark.django_db
def test_combined_prefetch_many_to_many_lazy_result(
    data_fixture, django_assert_num_queries
):
    """
    A prefetched many-to-many relation must iterate without hitting the database,
    but re-querying it (order_by/filter) must lazily build a queryset scoped to
    that row's relation rather than the whole target table.
    """

    user = data_fixture.create_user()
    table = data_fixture.create_database_table(user=user)
    field = data_fixture.create_multiple_select_field(table=table)
    a = data_fixture.create_select_option(field=field, value="A", order=0)
    b = data_fixture.create_select_option(field=field, value="B", order=1)
    c = data_fixture.create_select_option(field=field, value="C", order=2)

    RowHandler().create_rows(
        user=user,
        table=table,
        rows_values=[{f"field_{field.id}": [a.id, b.id]}, {f"field_{field.id}": []}],
    )

    model = table.get_model()
    rows = list(
        model.objects.all()
        .order_by("id")
        .multi_field_prefetch(
            CombinedForeignKeyAndManyToManyMultipleFieldPrefetch(
                SelectOption, [f"field_{field.id}"], skip_target_check=True
            )
        )
    )
    rel = getattr(rows[0], f"field_{field.id}")
    empty = getattr(rows[1], f"field_{field.id}")

    with django_assert_num_queries(0):
        assert [o.id for o in rel.all()] == [a.id, b.id]
        assert len(rel.all()) == 2
        assert bool(rel.all()) is True
        assert bool(empty.all()) is False

    # Re-querying scopes to this row's relation (c is not selected on this row).
    assert [o.id for o in rel.order_by("-order")] == [b.id, a.id]
    assert list(rel.filter(value="A")) == [a]
    assert c.id not in [o.id for o in rel.all()]


@pytest.mark.django_db
@pytest.mark.skipif(not BACKPORTED, reason="the backport is not installed")
def test_rows_api_returns_the_same_with_and_without_the_backport(
    api_client, data_fixture
):
    user, jwt = data_fixture.create_user_and_token()
    table = data_fixture.create_database_table(user=user)
    data_fixture.create_text_field(table=table, name="Nom", primary=True)
    single = data_fixture.create_single_select_field(table=table, name="Statut")
    multiples = [
        data_fixture.create_multiple_select_field(table=table, name=f"Tags {i}")
        for i in range(3)
    ]
    single_options = [
        data_fixture.create_select_option(field=single, value=v, color="red", order=o)
        for o, v in enumerate(["Ouvert", "Fermé"])
    ]
    options = {
        field.id: [
            data_fixture.create_select_option(
                field=field, value=v, color="blue", order=o
            )
            for o, v in enumerate(["A", "B", "C"])
        ]
        for field in multiples
    }
    RowHandler().create_rows(
        user=user,
        table=table,
        rows_values=[
            {
                f"field_{single.id}": single_options[i % 2].id if i % 3 else None,
                **{
                    f"field_{field.id}": [o.id for o in options[field.id][: i % 4]]
                    for field in multiples
                },
            }
            for i in range(12)
        ],
    )
    url = reverse("api:database:rows:list", kwargs={"table_id": table.id})

    def read():
        response = api_client.get(
            url, {"user_field_names": "true"}, HTTP_AUTHORIZATION=f"JWT {jwt}"
        )
        assert response.status_code == 200, response.json()
        return response.json()

    with_backport = read()
    select_perf.uninstall()
    try:
        without_backport = read()
    finally:
        select_perf.install()

    assert with_backport == without_backport
    assert with_backport["results"][2]["Tags 0"] == [
        {"id": options[multiples[0].id][0].id, "value": "A", "color": "blue"},
        {"id": options[multiples[0].id][1].id, "value": "B", "color": "blue"},
    ]

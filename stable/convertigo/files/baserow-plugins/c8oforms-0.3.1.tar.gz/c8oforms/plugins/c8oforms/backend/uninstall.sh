#!/bin/bash
# Bash strict mode: http://redsymbol.net/articles/unofficial-bash-strict-mode/
set -euo pipefail

# This file is automatically run by Baserow when the plugin is uninstalled.
# The plugin has no migration and no data, so there is nothing to undo here:
# Baserow `pip uninstall`s the module after this script.
